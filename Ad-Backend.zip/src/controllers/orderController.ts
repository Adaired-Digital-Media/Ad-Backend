import { Request, Response, NextFunction } from "express";
import Stripe from "stripe";
import Order from "../models/orderModel";
import Cart from "../models/cartModel";
import { CustomError } from "../middlewares/error";
import checkPermission from "../helpers/authHelper";
import axios from "axios";
import { BASE_DOMAIN } from "../utils/globals";
import { applyCoupon } from "./coupon.controller";
import {
  sendAdminNewOrderEmail,
  sendAdminPaymentReceivedEmail,
  sendOrderConfirmationEmail,
  sendPaymentConfirmationEmail,
} from "../utils/mailer";

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-11-20.acacia",
});

// Get currency based on IP
const getCurrencyFromRegion = async (ip: string): Promise<string> => {
  try {
    const response = await axios.get(`https://ipinfo.io/${ip}/json`);
    return response.data.country === "IN" ? "inr" : "usd";
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error detecting region:", error);
      throw new CustomError(500, error.message);
    }
    return "usd";
  }
};

// Fetch exchange rate
const getExchangeRate = async (currency: string): Promise<number> => {
  if (currency === "usd") return 1;
  try {
    const response = await axios.get(
      "https://api.exchangerate-api.com/v4/latest/USD"
    );
    return response.data.rates[currency.toUpperCase()] || 84;
  } catch (error) {
    if (error instanceof Error) {
      console.error("Error detecting currency:", error);
      throw new CustomError(500, error.message);
    }
    return 84; // Fallback rate
  }
};

// Helper to create Stripe session (in local currency)
const createStripeSession = async (
  cart: any,
  orderNumber: string,
  currency: string,
  exchangeRate: number,
  coupon: any,
  discountUSD: number,
  userId: string
): Promise<Stripe.Checkout.Session> => {
  const discountLocal = discountUSD * exchangeRate;

  return stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: cart.products.map((item: any) => {
      const product = item.product;
      const unitAmountUSD =
        item.wordCount && item.wordCount > 0
          ? (item.wordCount / 100) * product.pricePerUnit
          : product.pricePerUnit;
      const unitAmountLocal = unitAmountUSD * exchangeRate;

      let adjustedUnitAmount = unitAmountLocal;
      if (
        coupon &&
        coupon.discountType === "PRODUCT_SPECIFIC" &&
        coupon.specificProduct?.toString() === product._id.toString()
      ) {
        adjustedUnitAmount = unitAmountLocal * (1 - coupon.discountValue / 100);
      }

      return {
        price_data: {
          currency,
          product_data: { name: product.name },
          unit_amount: Math.round(adjustedUnitAmount * 100), // Local currency cents/paise
        },
        quantity: item.quantity,
      };
    }),
    ...(discountLocal > 0 && coupon?.discountType !== "PRODUCT_SPECIFIC"
      ? {
          discounts: [
            {
              coupon: await stripe.coupons
                .create({
                  amount_off: Math.round(discountLocal * 100),
                  currency,
                  duration: "once",
                })
                .then((c) => c.id),
            },
          ],
        }
      : {}),
    mode: "payment",
    success_url: `${BASE_DOMAIN}/expert-content-solutions/order/order-confirmation/${orderNumber}`,
    cancel_url: `${BASE_DOMAIN}/expert-content-solutions`,
    metadata: { userId, couponId: coupon?._id?.toString() || "" },
  });
};

// Helper to generate order number
const generateOrderNumber = (): string => {
  const now = new Date();
  return `${String(now.getDate()).padStart(2, "0")}${String(
    now.getMonth() + 1
  ).padStart(2, "0")}${String(now.getFullYear()).slice(-2)}${String(
    now.getHours()
  ).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}`;
};

// *********************************************************
// ************ Create an Order and Initiate Payment *******
// *********************************************************
export const createOrder = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const { couponCode, paymentMethod, ip } = req.body;

    if (!userId) {
      return next(
        new CustomError(401, "User must be logged in to create an order")
      );
    }

    const cart = await Cart.findOne({ userId }).populate("products.product");
    if (!cart || cart.products.length === 0) {
      return res.status(400).json({ message: "Cart is empty." });
    }

    const currency = await getCurrencyFromRegion(ip);
    const exchangeRate = await getExchangeRate(currency);
    const totalPriceUSD = cart.totalPrice;

    // Apply coupon and calculate totals in USD
    const { coupon, discountUSD, finalPriceUSD } = await applyCoupon(
      couponCode,
      cart,
      userId
    );
    const orderNumber = generateOrderNumber();

    // Create order object (in USD)
    const orderData = {
      orderNumber,
      userId,
      products: cart.products,
      totalQuantity: cart.totalQuantity,
      totalPrice: totalPriceUSD,
      couponDiscount: discountUSD,
      finalPrice: finalPriceUSD,
      couponId: coupon?._id || null,
      invoiceId: "Invoice_" + Date.now(),
      paymentMethod,
    };

    // Handle free order (finalPriceUSD = 0)
    if (finalPriceUSD === 0) {
      const newOrder = new Order({
        ...orderData,
        paymentId: null,
        paymentUrl: null,
        status: "Confirmed",
        paymentStatus: "Paid",
      });

      await newOrder.save();
      await cart.updateOne({ products: [], totalPrice: 0, totalQuantity: 0 });

      // Send emails asynchronously
      Promise.all([
        sendOrderConfirmationEmail(newOrder._id.toString()),
        sendAdminNewOrderEmail(newOrder._id.toString()),
      ]).catch((err) => console.error("Email sending failed:", err));

      return res.status(200).json({
        message: "Order created successfully",
        data: newOrder,
        redirectUrl: `${BASE_DOMAIN}/expert-content-solutions/order/order-confirmation/${orderNumber}`,
      });
    }

    // Create Stripe session (in local currency)
    const session = await createStripeSession(
      cart,
      orderNumber,
      currency,
      exchangeRate,
      coupon,
      discountUSD,
      userId
    );

    const newOrder = new Order({
      ...orderData,
      paymentId: session.id,
      paymentUrl: session.url,
      status: "Pending",
      paymentStatus: "Unpaid",
    });

    await newOrder.save();
    await cart.updateOne({ products: [], totalPrice: 0, totalQuantity: 0 });

    // Send emails asynchronously
    Promise.all([
      sendOrderConfirmationEmail(newOrder._id.toString()),
      sendAdminNewOrderEmail(newOrder._id.toString()),
    ]).catch((err) => console.error("Email sending failed:", err));

    res.status(201).json({
      message: "Order created successfully.",
      data: newOrder,
      sessionId: session.id,
    });
  } catch (error) {
    if (error instanceof Error) {
      next(new CustomError(500, error.message));
    } else {
      next(new CustomError(500, "An unknown error occurred."));
    }
  }
};

// *********************************************************
// ************** Handle Stripe Webhook Events *************
// *********************************************************

export const stripeWebhook = async (req: Request, res: Response) => {
  const sig = req.headers["stripe-signature"]!;
  if (!sig) {
    return res.status(400).send("Missing Stripe signature header");
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    if (err instanceof Error) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    } else {
      return res.status(400).send(`Webhook Error: ${err}`);
    }
  }

  switch (event.type) {
    case "checkout.session.completed":
      const session = event.data.object as Stripe.Checkout.Session;

      if (session.payment_status === "paid") {
        const updatedOrder = await Order.findOneAndUpdate(
          { paymentId: session.id },
          {
            status: "Confirmed",
            paymentStatus: "Paid",
            paymentDate: Date.now(),
          },
          { new: true }
        );
        if (updatedOrder) {
          // Send emails asynchronously
          Promise.all([
            sendPaymentConfirmationEmail(updatedOrder._id.toString()),
            sendAdminPaymentReceivedEmail(updatedOrder._id.toString()),
          ]).catch((err) => console.error("Email sending failed:", err));
        }
      }
      break;

    case "checkout.session.expired":
      const expiredSession = event.data.object as Stripe.Checkout.Session;
      await Order.findOneAndUpdate(
        { paymentId: expiredSession.id },
        { status: "Cancelled", paymentStatus: "Unpaid" },
        { new: true }
      );

      // Create a new checkout session if expired
      const cart = await Cart.findOne({
        userId: expiredSession.metadata.userId,
      });
      if (cart && cart.products.length > 0) {
        const newSession = await stripe.checkout.sessions.create({
          payment_method_types: ["card"],
          line_items: cart.products.map((product) => ({
            price_data: {
              currency: "usd",
              product_data: {
                name: product.product.name,
              },
              unit_amount: Math.round(product.totalPrice * 100),
            },
            quantity: product.quantity,
          })),
          mode: "payment",
          success_url: expiredSession.success_url,
          cancel_url: expiredSession.cancel_url,
          metadata: {
            userId: expiredSession.metadata.userId,
            couponId: expiredSession.metadata.couponId,
          },
        });

        await Order.findOneAndUpdate(
          { paymentId: expiredSession.id },
          {
            paymentUrl: newSession.url,
            paymentId: newSession.id,
          },
          { new: true }
        );
      }
      break;

    default:
  }

  res.status(200).json({ received: true });
};

// *********************************************************
// ************ Retrieve All Orders for Admin **************
// *********************************************************
export const getOrders = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const { orderNumber } = req.query;

    // Check Permission
    const permissionCheck = await checkPermission(userId, "orders", 2);
    if (!permissionCheck) {
      return res.status(403).json({ message: "Permission denied" });
    }

    let orders;
    if (orderNumber) {
      orders = await Order.findOne({ orderNumber: orderNumber })
        .populate(
          "userId",
          "-wishlist -orderHistory -refreshToken -createdAt -updatedAt -__v"
        )
        .populate({
          path: "products.product",
          populate: {
            path: "category",
            select: "name",
          },
        })
        .lean();
      if (!orders) {
        return res.status(404).json({ message: "Order not found." });
      }
    } else {
      orders = await Order.find()
        .sort({ createdAt: -1 })
        .populate({
          path: "products.product",
          populate: {
            path: "category",
            select: "name",
          },
        })
        .populate(
          "userId",
          "-wishlist -orderHistory -refreshToken -createdAt -updatedAt -__v"
        )
        .lean();
    }

    res.status(200).json({ data: orders });
  } catch (error) {
    if (error instanceof Error) {
      next(new CustomError(500, error.message));
    } else {
      next(new CustomError(500, "An unknown error occurred."));
    }
  }
};

// *********************************************************
// ************ Update Order (Admin) ***********************
// *********************************************************
export const updateOrder = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const { orderId } = req.query;
    const updateData = req.body;

    // Check Permission
    const permissionCheck = await checkPermission(userId, "orders", 3);
    if (!permissionCheck) {
      return res.status(403).json({ message: "Permission denied" });
    }

    const updatedOrder = await Order.findByIdAndUpdate(orderId, updateData, {
      new: true,
    });

    if (!updatedOrder) {
      return res.status(404).json({ message: "Order not found." });
    }

    res
      .status(200)
      .json({ message: "Order updated successfully.", data: updatedOrder });
  } catch (error) {
    if (error instanceof Error) {
      next(new CustomError(500, error.message));
    } else {
      next(new CustomError(500, "An unknown error occurred."));
    }
  }
};

// *********************************************************
// ************** Delete an Order by ID ********************
// *********************************************************
export const deleteOrder = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const { orderId } = req.query;

    // Check Permission
    const permissionCheck = await checkPermission(userId, "orders", 4);
    if (!permissionCheck) {
      return res.status(403).json({ message: "Permission denied" });
    }

    const deletedOrder = await Order.findByIdAndDelete(orderId);
    if (!deletedOrder) {
      return res.status(404).json({ message: "Order not found." });
    }

    res.status(200).json({ message: "Order deleted successfully." });
  } catch (error) {
    if (error instanceof Error) {
      next(new CustomError(500, error.message));
    } else {
      next(new CustomError(500, "An unknown error occurred."));
    }
  }
};

// *********************** USER ****************************

// *********************************************************
// ************ Retrieve Orders by User ID *****************
// *********************************************************
export const getOrdersByUserId = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { userId } = req;
    const { orderNumber } = req.query;

    let orders;
    if (orderNumber) {
      orders = await Order.findOne({ userId, orderNumber: orderNumber })
        .populate({
          path: "products.product",
          populate: {
            path: "category",
            model: "ProductCategory",
            select: "_id name",
          },
        })
        .lean();
      if (!orders) {
        return res.status(404).json({ message: "Order not found." });
      }
    } else {
      orders = await Order.find({ userId })
        .populate({
          path: "products.product",
          populate: {
            path: "category",
            model: "ProductCategory",
            select: "_id name",
          },
        })
        .sort({ createdAt: -1 })
        .lean();
    }

    res.status(200).json({ data: orders });
  } catch (error) {
    if (error instanceof Error) {
      next(new CustomError(500, error.message));
    } else {
      next(new CustomError(500, "An unknown error occurred."));
    }
  }
};
