export interface PermissionModuleType {
  name: string;
  value: string;
  status: boolean;
}
